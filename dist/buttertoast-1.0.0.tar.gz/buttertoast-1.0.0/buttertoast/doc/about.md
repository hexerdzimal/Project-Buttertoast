### Copyright (C) 2024 Matthias Ferstl, Fabian Kozlowski, Stefan Leippe, Malte Muthesius
This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License
This program comes with ABSOLUTELY NO WARRANTY; 
This is free software, and you are welcome to redistribute it under certain conditions;
For more information, contact: mail@matthias-ferstl.de